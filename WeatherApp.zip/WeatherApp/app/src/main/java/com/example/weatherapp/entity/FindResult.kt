package com.example.weatherapp.entity

import com.google.gson.annotations.SerializedName

data class FindResult(
    @SerializedName(value = "list")
    val items: List<City>
)

data class City(
    val id: Int = 0,
    val name: String = "",
    @SerializedName(value = "weather")
    val weatherList : List<Weather>,
    val main : Main
)

data class Weather(
    val description : String = "",
    val icon : String = ""
)

data class Main(
    val temp : Float
)