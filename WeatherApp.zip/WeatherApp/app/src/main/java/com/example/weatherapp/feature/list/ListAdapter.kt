package com.example.weatherapp.feature.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.weatherapp.R
import com.example.weatherapp.entity.City
import kotlinx.android.synthetic.main.row_city_layout.view.*

class ListAdapter () : RecyclerView.Adapter<ListAdapter.ViewHolder>() {

    private var items : List<City>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.row_city_layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount() = items?.size ?: 0

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        items?.let {
            val city = it[position]
//            holder.itemView.imgIcon
            holder.itemView.apply {
                if(city.weatherList.size > 0) {
                    tvCloudState.text = city.weatherList[0].description
                    Glide.with(this.context)
                        .load("http://openweathermap.org/img/w/${city.weatherList[0].icon}.png")
                        .into(imgIcon)
                }
                tvTemperature.text = city.main.temp.toString()
                tvCityName.text = city.name
            }
        }
    }

    fun data(items: List<City>) {
        this.items = items
        notifyDataSetChanged()
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

    }
}