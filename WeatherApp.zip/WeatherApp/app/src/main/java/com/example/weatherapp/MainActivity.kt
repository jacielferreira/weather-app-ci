package com.example.weatherapp

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.weatherapp.api.RetrofitManager
import com.example.weatherapp.entity.FindResult
import com.example.weatherapp.feature.list.ListAdapter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.custom_list_top_bar.view.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private val adapter = ListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initUI()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.list_menu, menu)

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.menu_setting -> {
                val intent = Intent(this, SettingActivity::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    fun initUI() {

        rvCities.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        btnSearch.setOnClickListener {
            if(isDeviceConnected()) {
                progressBar.visibility = View.VISIBLE
                // API START
                val call = RetrofitManager
                    .getWeatherService()
                    .find(etLocation.text.toString(), Const.WEATHER_API_KEY)

                call.enqueue(object : Callback<FindResult> {
                    override fun onFailure(call: Call<FindResult>, t: Throwable) {
                        progressBar.visibility = View.GONE
                        Log.d("felipedev", "ERROR", t)
                    }

                    override fun onResponse(call: Call<FindResult>, response: Response<FindResult>) {
                        progressBar.visibility = View.GONE
                        if (response.isSuccessful) {
                            val result = response.body()
                            result.let {
                                adapter.data(it!!.items)
                            }
                        }
                    }

                })
            } else {
                Toast.makeText(applicationContext, "Device isnt connected to internet", Toast.LENGTH_SHORT).show()
            }
        }
    }


    fun isDeviceConnected(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.activeNetworkInfo

        return netInfo != null && netInfo.isConnected
    }
}
