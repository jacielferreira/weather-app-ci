package com.example.weatherapp

object Const {
    const val WEATHER_API_KEY = "2ecc64d8a13a2fe38c2259076687a4ab"
    const val WEATHER_BASE_URL = "http://api.openweathermap.org/data/2.5/"
}