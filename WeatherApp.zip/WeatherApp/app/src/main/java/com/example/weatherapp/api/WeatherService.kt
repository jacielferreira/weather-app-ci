package com.example.weatherapp.api

import com.example.weatherapp.entity.FindResult
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherService {

    @GET(value = "find")
    fun find(
        @Query(value = "q") cityName: String,
        @Query(value = "appid") appId: String) : Call<FindResult>

}